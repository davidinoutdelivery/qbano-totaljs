// WebCounter module
INSTALL('module', 'https://modules.totaljs.com/latest/webcounter.js');

// Request stats module
INSTALL('module', 'https://modules.totaljs.com/latest/reqstats.js');

// Total.js monitoring
INSTALL('module', 'https://modules.totaljs.com/latest/monitor.js');